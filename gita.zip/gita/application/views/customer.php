<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0">CUSTOMER</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item active">Customer</li>
          </ol>
        </div>
      </div>
    </div>
  </div>

  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <!-- Card abu-abu gelap -->
      <div class="card bg-secondary text-white shadow">
        <div class="card-header d-flex justify-content-between align-items-center">
          <span>Data Customer</span>
          <button class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#exampleModal">
            <i class="fa fa-plus"></i> Tambah Customer
          </button>
        </div>

        <div class="card-body">
          <table class="table table-bordered table-dark mb-0">
            <thead class="bg-secondary">
              <tr>
                <th style="width: 50px;">NO</th>
                <th>Nama Customer</th>
                <th>Alamat</th>
                <th>No Telepon</th>
                <th colspan="2">AKSI</th>
              </tr>
            </thead>
            <tbody>
              <?php $no = 1; foreach ($customer as $c): ?>
              <tr>
                <td><?= $no++ ?></td>
                <td><?= $c->nama_customer ?></td>
                <td><?= $c->alamat ?></td>
                <td><?= $c->no_telp ?></td>
                <td onclick="javascript: return confirm('apakah anda yakin hapus')"><?php echo anchor('customer/hapus/'.$c->id_customer,'<div class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></div>')?></td> 
                <td><?php echo anchor('customer/edit/'. $c->id_customer,'<div class="btn btn-primary btn-sm"><i class="fa fa-edit"></i></div>')?></td> 
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </section>
</div>

<!-- Modal Tambah Customer -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content bg-secondary">
      <div class="modal-header text-white">
        <h5 class="modal-title" id="exampleModalLabel">Form Input Customer</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form method="post" action="<?= base_url('index.php/customer/tambah_aksi'); ?>">
        <div class="modal-body">
          <div class="mb-3">
            <label for="nama_customer" class="form-label">Nama Customer</label>
            <input type="text" name="nama_customer" id="nama_customer" class="form-control" required>
          </div>

          <div class="mb-3">
            <label for="alamat" class="form-label">Alamat</label>
            <input type="text" name="alamat" id="alamat" class="form-control" required>
          </div>

          <div class="mb-3">
            <label for="no_telp" class="form-label">No Telepon</label>
            <input type="text" name="no_telp" id="no_telp" class="form-control" required>
          </div>
        </div>
        <div class="modal-footer">
          <button type="reset" class="btn btn-primary" data-bs-dismiss="modal">Batal</button>
          <button type="submit" class="btn btn-danger">Simpan</button>
        </div>
      </form>
    </div>
  </div>
</div>
