<div class="content-wrapper">
  <section class="content">
    <div class="container-fluid">
      <!-- Card abu-abu gelap -->
      <div class="card bg-secondary text-white shadow">
        <div class="card-header">
          <h5 class="mb-0">Edit Kategori</h5>
        </div>

        <div class="card-body">
          <!-- Form -->
          <form action="<?= base_url('index.php/kategori/update'); ?>" method="post">
            <div class="form-group mb-3">
              <label for="nama_kategori" class="bg-secondary p-2 rounded d-block text-white">NAMA KATEGORI</label>
              <input type="hidden" name="id_kategori" value="<?= $kategori->id_kategori ?>">
              <input type="text" name="nama_kategori" id="nama_kategori" value="<?= $kategori->nama_kategori ?>" class="form-control text-white" required>
            </div>

            <!-- Tombol -->
            <button type="submit" class="btn btn-primary">Simpan</button>
            <button type="reset" class="btn btn-danger">Reset</button>
          </form>
        </div>

      </div>
    </div>
  </section>
</div>
