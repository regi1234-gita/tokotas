<!DOCTYPE html>
<html >
<head>
    <title>Biodata diri</title>
</head>
<body>

    <table border="1px solid black">

    <tr>
        <th>NAMA SISWA</th>
        <th>KELAS</th>
        <th>JURUSAN</th>
        <th>JENIS KELAMIN</th>
        <th>TANGGAL LAHIR</th>
        <th>EMAIL</th>
</tr>

  <?php foreach ($siswa as $siswa) :?>

     <tr>
        <td><?php echo $siswa['nama'];?></td>
        <td><?php echo $siswa['kelas'];?></td>
        <td><?php echo $siswa['jurusan'];?></td>
        <td><?php echo $siswa['jenis_kelamin'];?></td>
        <td><?php echo $siswa['tanggal_lahir'];?></td>
        <td><?php echo $siswa['email'];?></td>
    </tr>

    <?php endforeach; ?>
        

</table>
    
</body>
</html>