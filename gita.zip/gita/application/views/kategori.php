<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0">KATEGORI</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item active">Kategori</li>
          </ol>
        </div>
      </div>
    </div>
  </div>

  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <!-- Card abu-abu gelap -->
      <div class="card bg-secondary text-white shadow">
        <div class="card-header d-flex justify-content-between align-items-center">
          <span>Data Kategori</span>
          <button class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#exampleModal">
            <i class="fa fa-plus"></i> Tambah Kategori
          </button>
        </div>

        <div class="card-body">
          <table class="table table-bordered table-dark mb-0">
            <thead class="bg-secondary">
              <tr>
                <th style="width: 50px;">NO</th>
                <th>NAMA KATEGORI</th>
                <th colspan="2">AKSI</th>
              </tr>
            </thead>
            <tbody>
              <?php $no = 1; foreach ($kategori as $row): ?>
              <tr>
                <td><?= $no++ ?></td>
                <td><?= $row->nama_kategori ?></td>
                <td onclick="javascript: return confirm('apakah anda yakin hapus')"><?php echo anchor('kategori/hapus/'.$row->id_kategori,'<div class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></div>')?></td> 
                <td><?php echo anchor('kategori/edit/'. $row->id_kategori,'<div class="btn btn-primary btn-sm"><i class="fa fa-edit"></i></div>')?></td> 
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </section>
</div>

<!-- Modal Tambah Kategori -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content bg-secondary">
      <div class="modal-header text-white">
        <h5 class="modal-title" id="exampleModalLabel">Form Input Kategori</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form method="post" action="<?= base_url('index.php/kategori/tambah_aksi'); ?>">
        <div class="modal-body">
          <div class="mb-3">
            <label for="kategori" class="form-label">Kategori</label>
            <input type="text" name="kategori" id="kategori" class="form-control" required>
          </div>
        </div>
        <div class="modal-footer">
          <button type="reset" class="btn btn-primary" data-bs-dismiss="modal">Batal</button>
          <button type="submit" class="btn btn-danger">Simpan</button>
        </div>
      </form>
    </div>
  </div>
</div>
