<div class="content-wrapper">
  <!-- Content Header -->
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0">PRODUK</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item active">Produk</li>
          </ol>
        </div>
      </div>
    </div>
  </div>

  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <div class="card bg-secondary text-white shadow">
        <div class="card-header d-flex justify-content-between align-items-center">
          <span>Data Produk</span>
          <button class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#exampleModal">
            <i class="fa fa-plus"></i> Tambah Produk
          </button>
        </div>

        <div class="card-body">
          <table class="table table-bordered table-dark mb-0">
            <thead class="bg-secondary">
              <tr>
                <th style="width: 50px;">NO</th>
                <th>FOTO</th>
                <th>NAMA PRODUK</th>
                <th>DESKIRIPSI</th>
                <th>HARGA</th>
                <th>STOK</th>
              </tr>
            </thead>
            <tbody>
              <?php $no = 1; foreach ($produk as $p): ?>
              <tr>
                <td><?= $no++ ?></td>
                <td>
                <img src="<?= base_url('assets/foto/' . $p->foto) ?>" alt="Foto Produk" width="100">
              </td>
                <td><?= $p->nama_produk ?></td>
                <td><?= $p->deskripsi ?></td>
                <td><?= $p->harga ?></td>
                <td><?= $p->stok ?></td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </section>
</div>

<!-- Modal Tambah Produk -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content bg-secondary">
      <div class="modal-header text-white">
        <h5 class="modal-title" id="exampleModalLabel">Form Input Produk</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

      <?= form_open_multipart('produk/tambah_aksi'); ?>
  <div class="modal-body">

  <div class="mb-3">
  <label for="nama_produk" class="form-label text-white">Nama Produk</label>
  <select name="nama_produk" id="nama_produk" class="form-control bg-secondary text-white" required>
    <option value="">-- Pilih Produk --</option>
    <option value="tas selempang">tas selempang</option>
    <option value="tas laptop">tas laptop</option>
    <option value="tote bag">tote bag</option>
    <option value="tas ransel">tas ransel</option>
    <option value="tas ransel">koper</option>
  </select>
</div>


<div class="mb-3">
  <label for="deskripsi" class="form-label">Deskripsi</label>
  <textarea name="deskripsi" id="deskripsi" class="form-control" required></textarea>
</div>



<div class="mb-3">
  <label for="harga" class="form-label text-white">Harga</label>
  <div class="input-group">
    <span class="input-group-text bg-dark text-white">Rp</span>
    <input type="number" name="harga" id="harga" class="form-control bg-secondary text-white" placeholder="Contoh: 150.000" required>
  </div>
</div>

<div class="mb-3">
  <label for="stok" class="form-label text-white">Stok</label>
  <input type="number" name="stok" id="stok" class="form-control bg-secondary text-white" value="100" required>
</div>

<div class="mb-3">
      <label for="foto" class="form-label">Upload Foto</label>
      <input type="file" name="foto" id="foto" class="form-control" required>
    </div>



  </div>
  <div class="modal-footer">
    <button type="reset" class="btn btn-primary" data-bs-dismiss="modal">Batal</button>
    <button type="submit" class="btn btn-danger">Simpan</button>
  </div>
<?= form_close(); ?>
