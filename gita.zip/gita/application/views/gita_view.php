<!DOCTYPE html>
<html>
<head>
    <title>gita_view</title>
</head>
<body>
    
     <h1>tetap semangat dan  jangan menyerah </h1>
     <hr>
      <p>belajar menerima keadaan </p>

</body>
</html>