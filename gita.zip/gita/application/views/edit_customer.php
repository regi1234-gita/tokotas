<div class="content-wrapper">
  <section class="content">
    <div class="container-fluid">
      <!-- Card abu-abu gelap -->
      <div class="card bg-secondary text-white shadow">
        <div class="card-header">
          <h5 class="mb-0">Edit Customer</h5>
        </div>

        <div class="card-body">
          <!-- Form -->
          <form action="<?= base_url('index.php/customer/update'); ?>" method="post">
            <div class="form-group mb-3">
              <label>NAMA CUSTOMER</label>
              <input type="hidden" name="id" value="<?= $customer->id_customer ?>">
              <input type="text" name="nama" value="<?= $customer->nama_customer ?>" class="form-control">
            </div>

            <div class="form-group mb-3">
              <label>Alamat</label>
              <input type="text" name="alamat" value="<?= $customer->alamat ?>" class="form-control">
            </div>

            <div class="form-group mb-4">
              <label>NO TELEPON</label>
              <input type="text" name="no_telp" value="<?= $customer->no_telp ?>" class="form-control">
            </div>

            <!-- Tombol -->
            <button type="submit" class="btn btn-primary">Simpan</button>
            <button type="reset" class="btn btn-danger">Reset</button>
          </form>
        </div>

      </div>
    </div>
  </section>
</div>
