<div class="content-wrapper">
  <!-- Content Header -->
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0">PESANAN</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item active">Pesanan</li>
          </ol>
        </div>
      </div>
    </div>
  </div>

 
  <section class="content">
    <div class="container-fluid">
      <div class="card bg-secondary text-white shadow">
        <div class="card-header d-flex justify-content-between align-items-center">
          <span>Data Pesanan</span>
          <button class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#modalPesanan">
            <i class="fa fa-plus"></i> Tambah Pesanan
          </button>
        </div>

      
<div class="card-body">
    <table class="table table-bordered table-dark mb-0">
        <thead class="bg-secondary">
            <tr>
                <th style="width: 50px;">NO</th>
                <th>NAMA CUSTOMER</th>
                <th>NAMA PESANAN</th> 
                <th>JUMLAH PESANAN</th>
                <th>TANGGAL PESANAN</th>
                <th>TOTAL HARGA</th>
                <th>STATUS</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 1; foreach ($pesanan as $p): ?>
            <tr>
                <td><?= $no++ ?></td>
                <td><?= $p->nama_customer ?></td>
                <td><?= $p->nama_pesanan ?></td>
                <td><?= $p->jumlah_pesanan?></td>
                <td><?= $p->tanggal_pesanan ?></td>
                <td>Rp<?= number_format($p->total_harga, 0, ',', '.') ?></td>
                <td><?= $p->status ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>




    <!-- Modal Tambah Pesanan -->
<div class="modal fade" id="modalPesanan" tabindex="-1" aria-labelledby="modalPesananLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content bg-secondary text-white">
      <div class="modal-header">
        <h5 class="modal-title" id="modalPesananLabel">Form Input Pesanan</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

      <form method="post" action="<?= base_url('index.php/pesanan/tambah_aksi'); ?>">
        <div class="modal-body">
          <div class="mb-3">
            <label for="nama_customer" class="form-label">Nama Customer</label>
            <input type="text" name="nama_customer" id="nama_customer" class="form-control" required>
          </div>

      

          <div class="mb-3">
       <label for="nama_pesanan" class="form-label">Nama Pesanan</label>
       <select id="nama_pesanan" name="nama_pesanan" class="form-control bg-secondary text-white" required>
        <option value="" data-harga="0">-- Pilih Pesanan --</option>
       <option value="Tas Selempang" data-harga="50000">Tas Selempang - Rp.50.000</option>
       <option value="Tas Laptop" data-harga="50000">Tas Laptop - Rp.50.000</option>
    <option value="Tote Bag" data-harga="15000">Tote Bag - Rp.15.000</option>
    <option value="Tas Ransel" data-harga="300000">Tas Ransel - Rp.300.000</option>
    <option value="koper" data-harga="900000">koper - Rp.900.000</option>
  </select>
</div>


          <div class="mb-3">
            <label for="jumlah_pesanan" class="form-label">Jumlah Pesanan</label>
            <input type="number" name="jumlah_pesanan" id="jumlah_pesanan" class="form-control bg-secondary text-white" min="1" required>
          </div>

          <div class="mb-3">
            <label for="tanggal_pesanan" class="form-label">Tanggal Pesanan</label>
            <input type="date" name="tanggal_pesanan" id="tanggal_pesanan" class="form-control bg-secondary text-white" required>
          </div>

          <div class="mb-3">
            <label for="total_harga" class="form-label">Total Harga</label>
            <input type="number" id="total_harga" name="total_harga" class="form-control bg-secondary text-white" readonly>
            <small class="text-light">Total harga dihitung otomatis dari produk & jumlah</small>
          </div>

          <div class="mb-3">
            <label for="status" class="form-label">Status</label>
            <select name="status" id="status" class="form-control bg-dark text-white" required>
              <option value="">-- Pilih Status --</option>
              <option value="Dikirim">Dikirim</option>
              <option value="Diproses">Diproses</option>
              <option value="menunggu pembayaran">Menunggu Pembayaran</option>
              <option value="Dibatalkan">Dibatalkan</option>
            </select>
          </div>
        </div>

        <div class="modal-footer">
          <button type="reset" class="btn btn-primary" data-bs-dismiss="modal">Batal</button>
          <button type="submit" class="btn btn-danger">Simpan</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Script untuk menghitung total harga -->

<script>
  const selectPesanan = document.getElementById("nama_pesanan");
  const jumlahPesanan = document.getElementById("jumlah_pesanan");
  const totalHarga = document.getElementById("total_harga");

  function updateTotalHarga() {
    const selectedOption = selectPesanan.options[selectPesanan.selectedIndex];
    const harga = parseInt(selectedOption.getAttribute("data-harga")) || 0;
    const jumlah = parseInt(jumlahPesanan.value) || 0;
    totalHarga.value = harga * jumlah;
  }

  selectPesanan.addEventListener("change", updateTotalHarga);
  jumlahPesanan.addEventListener("input", updateTotalHarga);
</script>


