<?php 

class Produk_model extends CI_Model {
    
    public function tampil_data()
    {
        return $this->db->get('produk');
    }

    public function input_data($data, $table)
    {
        $this->db->insert($table, $data);
    }

    public function detail_data($id) {
        return $this->db->get_where('produk', ['id_produk' => $id])->row();
    }

    public function kurangi_stok($nama_produk, $jumlah)
    {
        $this->db->where('nama_produk', $nama_produk);
        $produk = $this->db->get('produk')->row();

        if ($produk && $produk->stok >= $jumlah) {
            $stok_baru = $produk->stok - $jumlah;
            $this->db->where('nama_produk', $nama_produk);
            $this->db->update('produk', ['stok' => $stok_baru]);
        }
    }
}
