<?php

class siswa extends  CI_Model {
    public function get_data()
    {
      return $this->db->get('tb_gita')->result_array();
    }
}

