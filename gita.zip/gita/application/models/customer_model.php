<?php 

class Customer_model extends CI_Model{
    
    // Fungsi untuk menampilkan data customer
    public function tampil_data()
    {
        return $this->db->get('customer'); // Mengambil data dari tabel customer
    }

    // Fungsi untuk memasukkan data customer baru
    public function input_data($data, $table)
    {
        $this->db->insert($table, $data); // Menyisipkan data ke tabel customer
    }

    public function hapus_data($where,$table){
        $this->db->where($where);
        $this->db->delete($table);
    }

    public function edit_data($where, $table)
{
    return $this->db->get_where($table, $where);
}

    public function update_data($where,$data,$table){
        $this->db->where($where);
        $this->db->update($table,$data);
    }
}
