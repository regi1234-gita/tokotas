<?php
class Pesanan_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    // Fungsi untuk mengambil data pesanan
    public function tampil_data() {
        return $this->db->get('pesanan'); // Mengambil seluruh data dari tabel pesanan
    }

    // Fungsi untuk menambah pesanan baru
    public function insert_pesanan($data) {
        // Memasukkan data pesanan ke dalam tabel 'pesanan'
        return $this->db->insert('pesanan', $data); 
    }

    public function kurangi_stok($nama_produk, $jumlah)
    {
        $this->db->where('nama_produk', $nama_produk);
        $produk = $this->db->get('produk')->row();

        if ($produk && $produk->stok >= $jumlah) {
            $stok_baru = $produk->stok - $jumlah;
            $this->db->where('nama_produk', $nama_produk);
            $this->db->update('produk', ['stok' => $stok_baru]);
        }
    }
}

