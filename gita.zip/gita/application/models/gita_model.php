<?php
 
class gita extends CI_Model {
  public function get_data()
{
    
}

} 

 ?>