<?php 

class  gita extends CI_Controller {

 public function index (){
     $this->load->model('siswa');
     $data['siswa']= $this->siswa->get_data();

     $this->load->view('v_siswa', $data);
}
}

 ?> 


 