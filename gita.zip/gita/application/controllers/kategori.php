<?php

class Kategori extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('kategori_model'); // Ganti model sesuai dengan nama model kategori
    }

    public function index()
    {
        $data['kategori'] = $this->kategori_model->tampil_data()->result(); // Menampilkan data kategori

        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('kategori', $data); // Ganti view sesuai dengan kategori
        $this->load->view('templates/footer');
    }

    public function tambah_aksi()
    {
        // Ambil input dari form
        $kategori = $this->input->post('kategori');

        // Menyiapkan data yang akan disimpan
        $data = array(
            'nama_kategori' => $kategori
        );

        // Memasukkan data ke dalam model
        $this->kategori_model->input_data($data, 'kategori'); // Ganti 'kategori' dengan nama tabel kategori

        // Redirect ke halaman kategori
        redirect('kategori');
    }
    public function hapus($id) {
        $where = ['id_kategori' => $id];
        $this->kategori_model->hapus_data($where, 'kategori'); // ganti customer_model → kategori_model
        redirect('kategori'); // arahkan ke controller kategori
    }

    public function edit($id) {
        $where = array('id_kategori' => $id); 
        $data['kategori'] = $this->kategori_model->edit_data($where, 'kategori')->row();

        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('edit_kategori', $data);
        $this->load->view('templates/footer');
    }

    public function update() {
        $id = $this->input->post('id_kategori'); // name="id_kategori"
        $nama_kategori = $this->input->post('nama_kategori'); // name="nama_kategori"

        $data = array(
            'nama_kategori' => $nama_kategori,
        );

        $where = array(
            'id_kategori' => $id
        );

        $this->kategori_model->update_data($where, $data, 'kategori');
        redirect('kategori'); // kembali ke daftar kategori
    }

}

