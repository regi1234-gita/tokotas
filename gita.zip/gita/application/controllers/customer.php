<?php

class Customer extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('customer_model'); // Ganti model menjadi customer_model
    }

    public function index()
    {
        // Menampilkan data customer
        $data['customer'] = $this->customer_model->tampil_data()->result();

        // Menyertakan tampilan header, sidebar, dan footer
        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('customer', $data); // Ganti view menjadi customer
        $this->load->view('templates/footer');
    }

    public function tambah_aksi()
    {
        // Ambil input dari form
        $nama_customer = $this->input->post('nama_customer'); // Sesuaikan dengan nama input di form
        $alamat = $this->input->post('alamat');
        $no_telp = $this->input->post('no_telp');
    
        // Menyiapkan data yang akan disimpan
        $data = array(
            'nama_customer' => $nama_customer,
            'alamat' => $alamat, 
            'no_telp' => $no_telp, 
        );
    
        // Memasukkan data ke dalam model
        $this->customer_model->input_data($data, 'customer');
    
        // Redirect ke halaman customer
        redirect('customer');
    }

    public function hapus($id)
    {
            $where = ['id_customer' => $id];
            $this->load->model('customer_model'); // pastikan diload
            $this->customer_model->hapus_data($where, 'customer');
            redirect('customer');
        }
        
        public function edit($id)
        {
            $where = array('id_customer' => $id); 
            $data['customer'] = $this->customer_model->edit_data($where, 'customer')->row();
        
            $this->load->view('templates/header');
            $this->load->view('templates/sidebar');
            $this->load->view('edit_customer', $data);
            $this->load->view('templates/footer');
        }
        
        public function update() {
            $id = $this->input->post('id');
            $nama_customer = $this->input->post('nama');
            $alamat = $this->input->post('alamat');
            $no_telp = $this->input->post('no_telp');
        
            $data = array(
                'nama_customer' => $nama_customer,
                'alamat'        => $alamat,
                'no_telp'       => $no_telp,
            );
        
            $where = array(
                'id_customer' => $id  // Pastikan ini sesuai nama kolom di database
            );
        
            $this->customer_model->update_data($where, $data, 'customer');
        
            redirect('customer'); // Tanpa 'index.php'
        }
        
        }
        