<?php

class Pesanan extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Pesanan_model');
        $this->load->model('Produk_model'); // Pastikan model ini juga di-load
    }

    public function index()
    {
        $data['pesanan'] = $this->Pesanan_model->tampil_data()->result(); 
        $this->load->view('templates/header'); 
        $this->load->view('templates/sidebar'); 
        $this->load->view('pesanan', $data);
        $this->load->view('templates/footer');
    }

    public function tambah_aksi()
    {
        $nama_customer   = $this->input->post('nama_customer');
        $nama_pesanan    = $this->input->post('nama_pesanan');
        $jumlah_pesanan  = $this->input->post('jumlah_pesanan');
        $tanggal_pesanan = $this->input->post('tanggal_pesanan');
        $total_harga     = $this->input->post('total_harga');
        $status          = $this->input->post('status');

        
        $data = [
            'nama_customer'   => $nama_customer,
            'nama_pesanan'    => $nama_pesanan,
            'jumlah_pesanan'  => $jumlah_pesanan,
            'tanggal_pesanan' => $tanggal_pesanan,
            'total_harga'     => $total_harga,
            'status'          => $status
        ];

       
        $this->Pesanan_model->insert_pesanan($data);

       
        $this->Produk_model->kurangi_stok($nama_pesanan, $jumlah_pesanan);

        redirect('pesanan');
    }
}
