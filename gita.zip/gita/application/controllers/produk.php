<?php

class produk extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('produk_model'); // Ganti model sesuai dengan nama model produk
    }

    public  function index()
    {
        $data['produk'] = $this->produk_model->tampil_data()->result(); // Menampilkan data produk

        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('produk', $data); // Ganti view sesuai dengan kategori
        $this->load->view('templates/footer');
    }

    public function tambah_aksi()
{
    $nama_produk = $this->input->post('nama_produk');
    $deskripsi   = $this->input->post('deskripsi');
    $harga       = $this->input->post('harga');
    $stok        = $this->input->post('stok');
    $foto        = $_FILES['foto'];

    if ($foto = '') {
        $foto_name = '';
    } else {
        $config['upload_path']   = './assets/foto';
        $config['allowed_types'] = 'jpg|png|jpeg|gif';
        $config['max_size']      = 2048;

        $this->load->library('upload', $config);

        if (!$this->upload->do_upload('foto')) {
            echo "Upload Gagal"; die();
        } else {
            $foto_name = $this->upload->data('file_name');
        }
    }

    $data = array(
        'nama_produk' => $nama_produk,
        'deskripsi'   => $deskripsi,
        'harga'       => $harga,
        'stok'        => $stok,
        'foto'        => $foto_name // <-- ini penting!
    );

    $this->produk_model->input_data($data, 'produk');
    redirect('produk');
}
}